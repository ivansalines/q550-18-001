# Q550 Kick203 event-micro lens — v17.9

## Research question
How does the off-shell Shapley near-opposition A vs B arise on the two sides
of the original section B crossing xi = 210.861136603178? What is the signed
small prevalence along a fixed full11D reference axis?

## Primary action on the server
Run in the unpacked bundle directory:

```bash
bash scripts/run_on_server.sh 2>&1 | tee v17_9_console.log
```

Output: `q550_kick203_event_micro_v17_9_sendback.zip`.

To override external base locations, define `BASE_ROOT=/path/to/base` and
`SOURCE_ZIP=/path/to/x500/rebased/source_bundle.zip` before running.

## What is unchanged
The original v17.5 source code is retained verbatim as
`reference/original_run_oriented_flip_v17_5.py`, and the operational geometry
`frame_geometry.py` and model references are byte-for-byte copies.

The new `scripts/run_kick203_event_micro_v17_9.py` makes ONLY two functional
execution changes: (1) an explicitly nonuniform xi grid concentrated at the
observed crossing with sparse historical anchors, and (2) geometric xi-span
batching rather than sample-count batching for the cocycle integrator. It
keeps exactly the same ODE propagation, frame definitions, common restart,
Shapley counterfactual allocation, tolerances and epsilon variants.

The event probes are symmetrical at +/-[.025,.01,.005,.001,.00025,.00005,.00001] xi,
plus the exact floating-point crossing. The local regular grid is spaced .0025
xi on [cross-.15, cross+.35]. The original 0.25 xi historical lattice and a
short fragment of the already computed 0.025 xi grid are both kept as an
independent overlap check. No interpolation creates measurement samples.

## What is measured
- One-sided norm and signed vector components for A, B, S=A+B, M and delta.
- First A/B compensation and secondary S/M compensation.
- Frozen longitudinal/transverse 11D axes defined within each variant.
- Symmetric event-offset diagnostic and overlap check with the supplied
  previous 0.025 xi run.
- Pointwise algebraic recomposition closure.

## Scientific limits
The Shapley hybrids are OFF SHELL. The fact that B is exactly zero before
crossing might be a consequence of where the plus/minus common-restarted
histories are sampled, NOT an impulse carried by a material body. An apparent
jump of a Shapley contribution is not automatically a physical discontinuity.

The local signed transverse axes are *analysis charts*, not physically
material-attached axes. No topology, torsional flip, or causal law is certified.

## Existing data and reproducibility
`inputs/reference_step0025_*` come from the user-provided v17.5
`results/kick203_step0025` server run. Original source and 17.4 projector
sendback are included for source-level reproducibility. The external base
Q550 bundle and full x500 rebased transport source remain required on server.
`ORIGINAL_V17_5_SOURCE_SHA256.json` captures original source hashes.
The bundle manifest records every packaged file hash and source version.
