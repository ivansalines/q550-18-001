# Q550 kick203 event-micro lens v17.9

Original v17.5 full11D cocycle and exact symmetric Shapley definition are preserved.

B crossing xi = `210.861136603177698`

## Nearest left/right probes

```text
                              variant   crossing  nearest_left  nearest_right  left_gap  right_gap  left_B_norm  right_B_norm  left_delta_norm  right_delta_norm  right_AB_angle_deg
   standard__kick203__eps1e-08__hhalf 210.861137    210.861127     210.861147   0.00001    0.00001     0.281564      0.281565         0.285633          0.285632           91.905406
standard__kick203__eps1e-08__hquarter 210.861137    210.861127     210.861147   0.00001    0.00001     0.131301      0.131301         0.142453          0.142450           92.355308
   standard__kick203__eps3e-08__hhalf 210.861137    210.861127     210.861147   0.00001    0.00001     0.086262      0.086262         0.200382          0.200379           91.586827
standard__kick203__eps3e-08__hquarter 210.861137    210.861127     210.861147   0.00001    0.00001     0.042764      0.042764         0.187515          0.187513           91.715035
      tight__kick203__eps1e-08__hhalf 210.861137    210.861127     210.861147   0.00001    0.00001     0.281564      0.281565         0.285633          0.285632           91.905397
   tight__kick203__eps1e-08__hquarter 210.861137    210.861127     210.861147   0.00001    0.00001     0.131301      0.131301         0.142453          0.142450           92.355294
      tight__kick203__eps3e-08__hhalf 210.861137    210.861127     210.861147   0.00001    0.00001     0.086262      0.086262         0.200382          0.200379           91.586814
   tight__kick203__eps3e-08__hquarter 210.861137    210.861127     210.861147   0.00001    0.00001     0.042764      0.042764         0.187515          0.187513           91.715020
```

## Exact overlap with v17.5 xi step 0.025

```text
                              variant  matched      abs_RMS  relative_RMS      max_abs
   standard__kick203__eps1e-08__hhalf      111 5.030791e-08  4.927990e-07 1.463542e-07
standard__kick203__eps1e-08__hquarter      111 9.847856e-08  1.163829e-06 3.113202e-07
   standard__kick203__eps3e-08__hhalf      111 4.631106e-08  2.067958e-07 1.225238e-07
standard__kick203__eps3e-08__hquarter      111 8.220804e-08  3.690698e-07 2.544322e-07
      tight__kick203__eps1e-08__hhalf      111 5.228461e-08  5.121620e-07 1.296609e-07
   tight__kick203__eps1e-08__hquarter      111 9.616970e-08  1.136543e-06 2.745787e-07
      tight__kick203__eps3e-08__hhalf      111 5.085751e-08  2.270973e-07 1.699152e-07
   tight__kick203__eps3e-08__hquarter      111 8.274346e-08  3.714736e-07 2.144629e-07
```

## Interpretation boundary

The Shapley hybrids are off-shell mathematical counterfactuals, not physical trajectories.
At the B crossing, plus/minus histories change section sampling side relative to the common restart; a one-sided allocation jump must not be interpreted as a physical shock.
The signed frozen reference is fixed within each numerical variant and is not a gauge-independent physical torsion axis.
Event crossing is explicitly sampled for diagnostics but exact-side branch selection at floating-point equality may be convention-dependent. Prefer one-sided offsets.
