#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
BASE_ROOT="${BASE_ROOT:-/root/elab1/hysteresis/q550_full11D_transverse_slow_state_dense_sampling_v1_bundle}"
SOURCE_ZIP="${SOURCE_ZIP:-/root/elab1/hysteresis/q550_x55_multiloop_transport_runner_v1_1_bundle/q550_x55_multiloop_transport_x50000_rebased_checked_v1/q550_x55_multiloop_transport_law_v2_bundle.zip}"
OUT="$ROOT/results/kick203_event_micro_v17_9"
mkdir -p "$OUT"
python3.13 scripts/run_kick203_event_micro_v17_9.py \
  --base-root "$BASE_ROOT" \
  --source-bundle-zip "$SOURCE_ZIP" \
  --singular-vectors "$ROOT/inputs/singular_direction_vectors.csv" \
  --v17-4-sendback "$ROOT/inputs/v17_4_original_sendback.zip" \
  --kicks 203 \
  --step 0.25 --micro-step 0.0025 --micro-pre 0.15 --micro-post 0.35 \
  --overlap-xi-min 210.5 --overlap-xi-max 211.25 \
  --out "$OUT" 2>&1 | tee "$OUT/generator_console.log"
python3.13 scripts/audit_kick203_event_micro_v17_9.py \
  --allocation-csv "$OUT/oriented_shapley_allocation.csv" \
  --shapley-npz "$OUT/oriented_shapley_arrays.npz" \
  --reference-allocation-csv "$ROOT/inputs/reference_step0025_oriented_shapley_allocation.csv" \
  --reference-shapley-npz "$ROOT/inputs/reference_step0025_oriented_shapley_arrays.npz" \
  --out "$OUT/event_lens_audit" 2>&1 | tee "$OUT/audit_console.log"
python3.13 scripts/pack_sendback_v17_9.py --result-dir "$OUT" --out "$ROOT/q550_kick203_event_micro_v17_9_sendback.zip"
