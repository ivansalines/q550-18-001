#!/usr/bin/env python3
"""Pack the new measurement and executable lineage, leaving source archives intact."""
import argparse, zipfile,hashlib,json
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--result-dir',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
root=Path(__file__).resolve().parents[1]
files=list(f for f in a.result_dir.rglob('*') if f.is_file())
files += [f for f in (root/'scripts').glob('*.py') if f.is_file()]
files += [root/'scripts/run_on_server.sh',root/'ORIGINAL_V17_5_SOURCE_SHA256.json',root/'README.md',root/'requirements.txt']
a.out.parent.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(a.out,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for f in sorted(set(files)):
    if f.resolve()==a.out.resolve():continue
    z.write(f,arcname=str(f.relative_to(root)))
print('sendback',a.out, 'files',len(files))
